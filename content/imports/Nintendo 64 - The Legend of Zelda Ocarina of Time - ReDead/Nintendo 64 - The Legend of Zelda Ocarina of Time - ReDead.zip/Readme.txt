Here is the Redead from Legend of Zelda, the textures are a bit large but they still work.
If you use this could you give credit to Alec Pike, or at least try to remember my name?
If you have any comments or complaints or need help with the model or something e-mail me at alec.pike@gmail.com

---------

This model was fixed to an unanimated pose by Zerox. No credit necessary for that though.